This folder includes the datasets we used for our research. Below we list how specific files are mentioned in the paper:

- 8combined.csv: Combination of all 8 datasets listed in the paper
- Dronology.csv: Dronology dataset
- ds2.csv: Helpdesk dataset
- ds3.csv: User mgmt dataset
- INDcombined.csv: Combination of seven industrial datasets
- leeds.csv: Leeds library dataset
- promise-reclass.csv: PROMISE dataset 
- reqview.csv: ReqView dataset
- wasp.csv: WASP dataset
